$('.scroll-area').overlayScrollbars({
  className: "os-theme-dark",
  clickScrolling : true
});