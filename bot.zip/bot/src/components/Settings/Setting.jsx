import React, { Component } from 'react';

import Sidebar from '../Sidebar/Sidebar';
class Setting extends Component {
    render() {
        return(
            <div>
                <div id="page">
                    <Sidebar />
                </div>
                
            </div>
        )
    }
} 

export default Setting;