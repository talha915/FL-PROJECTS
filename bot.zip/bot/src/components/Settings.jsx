import React, { Component } from 'react';

import Setting from './Settings/Setting';

class Settings extends Component {
    render() {
        return(
            
            <Setting />
            
        )
    }
}

export default Settings;