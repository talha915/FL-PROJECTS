import React, { Component } from 'react';

import Dashboard from './Dashboard/Dashboard';

class Index extends Component {
    render() {
        return(
            
            <Dashboard />
            
        )
    }
}

export default Index;