import React from 'react';
import Router from './components/Routers/Router';

function App() {
  return (
    <div >
      <Router />
    </div>
  );
}

export default App;
