$('.file-upload').file_upload();
